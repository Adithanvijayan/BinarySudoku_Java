import java.util.Scanner;
import java.util.Arrays;
public class binarysudoku
{
	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		int size,i,j,k,l,x,y,flag=0,flag1=0,flag2=0,flag3=0,count1=0,count0=0,mid;	
		char n;
		System.out.println("Binary Sudoku : ");
		System.out.println("Enter the grid size : ");
		size=scan.nextInt();
		mid=(int)size/2;
		char input[][] = new char[size+2][size+2];
		for(i=0;i<=size+1;i++)
		{
			for(j=0;j<=size+1;j++)
			{
				input[i][j]='2';
			}
		}
		System.out.println("Enter the "+size+"X"+size+" grid : ");
		for(i=1;i<=size;i++)
		{
			for(j=1;j<=size;j++)
			{
				input[i][j]=scan.next().charAt(0);
			}
		}

		System.out.println("Input : ");
		System.out.print(" ");
		for(i=1;i<=size;i++)
		{
			System.out.print(" "+i);
		}
		System.out.println(" ");
		System.out.print(" ");
		for(i=1;i<=size;i++)
		{
			System.out.print(" _");
		}
		System.out.println(" ");
		for(i=1;i<=size;i++)
		{
			System.out.print(i+"|");
			for(j=1;j<=size;j++)
			{
				System.out.print(input[i][j]+" ");
			}
			System.out.println(" ");
		}

		while(true)
		{
			for(i=1;i<=size;i++)
			{
				for(j=1;j<=size;j++)
				{
					if(input[i][j-1]=='0' && input[i][j+1]=='0' && input[i][j]=='.')
					{
						input[i][j]='1';
						flag=1;
					}
					if(input[i][j-1]=='1' && input[i][j+1]=='1' && input[i][j]=='.')
					{
						input[i][j]='0';
						flag=1;
					}
					if(input[i][j]=='0' && input[i][j+1]=='0' && input[i][j-1]=='.')
					{
						input[i][j-1]='1';
						flag=1;
					}
					if(input[i][j]=='0' && input[i][j-1]=='0' && input[i][j+1]=='.')
					{
						input[i][j+1]='1';
						flag=1;
					}
					if(input[i][j]=='1' && input[i][j+1]=='1' && input[i][j-1]=='.')
					{
						input[i][j-1]='0';
						flag=1;
					}
					if(input[i][j]=='1' && input[i][j-1]=='1' && input[i][j+1]=='.')
					{
						input[i][j+1]='0';
						flag=1;
					}
					if(input[i-1][j]=='0' && input[i+1][j]=='0' && input[i][j]=='.')
					{
						input[i][j]='1';
						flag=1;
					}
					if(input[i-1][j]=='1' && input[i+1][j]=='1' && input[i][j]=='.')
					{
						input[i][j]='0';
						flag=1;
					}
					if(input[i][j]=='0' && input[i+1][j]=='0' && input[i-1][j]=='.')
					{
						input[i-1][j]='1';
						flag=1;
					}
					if(input[i][j]=='0' && input[i-1][j]=='0' && input[i+1][j]=='.')
					{
						input[i+1][j]='1';
						flag=1;
					}
					if(input[i][j]=='1' && input[i+1][j]=='1' && input[i-1][j]=='.')
					{
						input[i-1][j]='0';
						flag=1;
					}
					if(input[i][j]=='1' && input[i-1][j]=='1' && input[i+1][j]=='.')
					{
						input[i+1][j]='0';
						flag=1;
					}
				}
			}

			if(flag==0)
			{
				for(i=1;i<=size;i++)
				{
					for(j=1;j<=size;j++)
					{
						if(input[i][j]=='.')
						{
							flag1=1;
							break;
						}
					}
					if(flag1==1)
						break;
				}
				if(flag1==1)
				{
					for(i=1;i<=size;i++)
					{
						for(j=1;j<=size;j++)
						{
							if(input[i][j]=='1')
							{
								count1++;
							}
							if(input[i][j]=='0')
							{
								count0++;
							}
						}
						if(count0==mid && count1<mid)
						{
							for(j=1;j<=size;j++)
							{
								if(input[i][j]=='.')
								{
									input[i][j]='1';
									flag2=1;
								}
							}
						}
						if(count1==mid && count0<mid)
						{
							for(j=1;j<=size;j++)
							{
								if(input[i][j]=='.')
								{
									input[i][j]='0';
									flag2=1;
								}
							}
						}
						count0=0;
						count1=0;
					}

					for(i=1;i<=size;i++)
					{
						for(j=1;j<=size;j++)
						{
							if(input[j][i]=='1')
							{
								count1++;
							}
							if(input[j][i]=='0')
							{
								count0++;
							}
						}
						if(count0==mid && count1<mid)
						{
							for(j=1;j<=size;j++)
							{
								if(input[j][i]=='.')
								{
									input[j][i]='1';
									flag2=1;
								}
							}
						}
						if(count1==mid && count0<mid)
						{
							for(j=1;j<=size;j++)
							{
								if(input[j][i]=='.')
								{
									input[j][i]='0';
									flag2=1;
								}
							}
						}
						count0=0;
						count1=0;
					}

				}
				flag1=0;
			}

			if(flag==0 && flag2==0)
			{
				System.out.println("Output :");
				System.out.print(" ");
				for(i=1;i<=size;i++)
				{
					System.out.print(" "+i);
				}
				System.out.println(" ");
				System.out.print(" ");
				for(i=1;i<=size;i++)
				{
					System.out.print(" _");
				}
				System.out.println(" ");
				for(i=1;i<=size;i++)
				{
					System.out.print(i+"|");
					for(j=1;j<=size;j++)
					{
						System.out.print(input[i][j]+" ");
					}
					System.out.println(" ");
				}
				break;
			}
			flag=0;
			flag2=0;
		}
	}
}