import java.util.Scanner;
import java.util.Arrays;
public class binarysudokufinal
{
	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		int size,i,j,k,l,x,y,flag=0,flag1=0,flag2=0,flag3=0,count1=0,count0=0,mid,mode,answer0=0,answer1=0,answer2=1,answer3=1,count2=0,count3=0,answer4=1,answer5=1;	
		char n;
		System.out.println("Binary Sudoku : ");
		System.out.println("Enter the grid size : ");
		size=scan.nextInt();
		if(size!=6 && size!=8 && size!=10 && size!=12 && size!=14)
		{
			System.out.println("Incorrect Grid Size");
			return ;
		}
		mid=(int)size/2;
		char input[][] = new char[size+2][size+2];
		for(i=0;i<=size+1;i++)
		{
			for(j=0;j<=size+1;j++)
			{
				input[i][j]='2';
			}
		}
		System.out.println("Enter the "+size+"X"+size+" grid : ");
		for(i=1;i<=size;i++)
		{
			for(j=1;j<=size;j++)
			{
				input[i][j]=scan.next().charAt(0);
			}
		}

		System.out.println("Input : ");
		System.out.print(" ");
		for(i=1;i<=size;i++)
		{
			System.out.print(" "+i);
		}
		System.out.println(" ");
		System.out.print(" ");
		for(i=1;i<=size;i++)
		{
			System.out.print(" _");
		}
		System.out.println(" ");
		for(i=1;i<=size;i++)
		{
			System.out.print(i+"|");
			for(j=1;j<=size;j++)
			{
				System.out.print(input[i][j]+" ");
			}
			System.out.println(" ");
		}
		System.out.println("Computer Mode('0') or Player Mode('1') : ");
		mode = scan.nextInt();
		if(mode==0)
		{

			while(true)
			{
				for(i=1;i<=size;i++)
				{
					for(j=1;j<=size;j++)
					{
						if(input[i][j-1]=='0' && input[i][j+1]=='0' && input[i][j]=='.')
						{
							input[i][j]='1';
							flag=1;
						}
						if(input[i][j-1]=='1' && input[i][j+1]=='1' && input[i][j]=='.')
						{
							input[i][j]='0';
							flag=1;
						}
						if(input[i][j]=='0' && input[i][j+1]=='0' && input[i][j-1]=='.')
						{
							input[i][j-1]='1';
							flag=1;
						}
						if(input[i][j]=='0' && input[i][j-1]=='0' && input[i][j+1]=='.')
						{
							input[i][j+1]='1';
							flag=1;
						}
						if(input[i][j]=='1' && input[i][j+1]=='1' && input[i][j-1]=='.')
						{
							input[i][j-1]='0';
							flag=1;
						}
						if(input[i][j]=='1' && input[i][j-1]=='1' && input[i][j+1]=='.')
						{
							input[i][j+1]='0';
							flag=1;
						}
						if(input[i-1][j]=='0' && input[i+1][j]=='0' && input[i][j]=='.')
						{
							input[i][j]='1';
							flag=1;
						}
						if(input[i-1][j]=='1' && input[i+1][j]=='1' && input[i][j]=='.')
						{
							input[i][j]='0';
							flag=1;
						}
						if(input[i][j]=='0' && input[i+1][j]=='0' && input[i-1][j]=='.')
						{
							input[i-1][j]='1';
							flag=1;
						}
						if(input[i][j]=='0' && input[i-1][j]=='0' && input[i+1][j]=='.')
						{
							input[i+1][j]='1';
							flag=1;
						}
						if(input[i][j]=='1' && input[i+1][j]=='1' && input[i-1][j]=='.')
						{
							input[i-1][j]='0';
							flag=1;
						}
						if(input[i][j]=='1' && input[i-1][j]=='1' && input[i+1][j]=='.')
						{
							input[i+1][j]='0';
							flag=1;
						}
					}
				}

				if(flag==0)
				{
					for(i=1;i<=size;i++)
					{
						for(j=1;j<=size;j++)
						{
							if(input[i][j]=='.')
							{
								flag1=1;
								break;
							}
						}
						if(flag1==1)
							break;
					}
					if(flag1==1)
					{
						for(i=1;i<=size;i++)
						{
							for(j=1;j<=size;j++)
							{
								if(input[i][j]=='1')
								{
									count1++;
								}
								if(input[i][j]=='0')
								{
									count0++;
								}
							}
							if(count0==mid && count1<mid)
							{
								for(j=1;j<=size;j++)
								{
									if(input[i][j]=='.')
									{
										input[i][j]='1';
										flag2=1;
									}
								}
							}
							if(count1==mid && count0<mid)
							{
								for(j=1;j<=size;j++)
								{
									if(input[i][j]=='.')
									{
										input[i][j]='0';
										flag2=1;
									}
								}
							}
							count0=0;
							count1=0;
						}

						for(i=1;i<=size;i++)
						{
							for(j=1;j<=size;j++)
							{
								if(input[j][i]=='1')
								{
									count1++;
								}
								if(input[j][i]=='0')
								{
									count0++;
								}
							}
							if(count0==mid && count1<mid)
							{
								for(j=1;j<=size;j++)
								{
									if(input[j][i]=='.')
									{
										input[j][i]='1';
										flag2=1;
									}
								}
							}
							if(count1==mid && count0<mid)
							{
								for(j=1;j<=size;j++)
								{
									if(input[j][i]=='.')
									{
										input[j][i]='0';
										flag2=1;
									}
								}
							}
							count0=0;
							count1=0;
						}

					}
					flag1=0;
				}

				if(flag==0 && flag2==0)
				{
					System.out.println("Output :");
					System.out.print(" ");
					for(i=1;i<=size;i++)
					{
						System.out.print(" "+i);
					}
					System.out.println(" ");
					System.out.print(" ");
					for(i=1;i<=size;i++)
					{
						System.out.print(" _");
					}
					System.out.println(" ");
					for(i=1;i<=size;i++)
					{
						System.out.print(i+"|");
						for(j=1;j<=size;j++)
						{
							System.out.print(input[i][j]+" ");
						}
						System.out.println(" ");
					}
					break;
				}
				flag=0;
				flag2=0;
			}

			for(i=1;i<=size;i++)
			{
				for(j=1;j<=size;j++)
				{
					if(input[i][j]=='1')
						count1++;
					if(input[i][j]=='0')
						count0++;
				}
				if(count0==mid && count1==mid)
				{
					answer0=1;
				}
				else
				{
					answer0=0;
					break;
				}
				count1=0;
				count0=0;
			}

			for(i=1;i<=size;i++)
			{
				for(j=1;j<=size;j++)
				{
					if(input[j][i]=='1')
						count1++;
					if(input[j][i]=='0')
						count0++;
				}
				if(count0==mid && count1==mid)
				{
					answer1=1;
				}
				else
				{
					answer1=0;
				}
				count0=0;
				count1=0;
			}

			for(i=1;i<=size;i++)
			{
				for(j=1;j<=size-2;j++)
				{
					if(input[i][j]==input[i][j+1] && input[i][j+1]==input[i][j+2])
					{
						answer2=0;
						break;
					}
					else
					{
						answer2=1;
					}
				}
				if(answer2==0)
					break;
			}

			for(i=1;i<=size;i++)
			{
				for(j=1;j<=size-2;j++)
				{
					if(input[j][i]==input[j+1][i] && input[j+1][i]==input[j+2][i])
					{
						answer3=0;
						break;
					}
					else
					{
						answer3=1;
					}
				}
				if(answer3==0)
					break;
			}

			for(i=1;i<=size;i++)
			{
				for(j=i+1;j<=size;j++)
				{
					for(k=1;k<=size;k++)
					{
						if(input[i][k]==input[j][k])
						{
							count2++;
						}
					}
					if(count2==size)
					{
						answer4=0;
						break;
					}
					count2=0;
				}
				if(answer4==0)
					break;
			}

			for(i=1;i<=size;i++)
			{
				for(j=i+1;j<=size;j++)
				{
					for(k=1;k<=size;k++)
					{
						if(input[k][i]==input[k][j])
						{
							count3++;
						}
					}
					if(count3==size)
					{
						answer5=0;
						break;
					}
					count3=0;
				}
				if(answer5==0)
					break;
			}

			if(answer0==1 && answer1==1 && answer2==1 && answer3==1 && answer4==1 && answer5==1)
			{
				System.out.println("Congratulations , answer is correct");
			}
			else
			{
				System.out.println("Sorry , answer is incorrect");
			}

		}
		else if(mode==1)
		{
			while(true)
			{
				System.out.println("Enter the x co-ordinate to move : ");
				x=scan.nextInt();
				if(x<=0 || x>size)
				{
					System.out.println("Incorrect x co-ordinate");
					continue;
				}
				System.out.println("Enter the y co-ordinate to move : ");
				y=scan.nextInt();
				if(y<=0 || y>size)
				{
					System.out.println("Incorrect y co-ordinate");
					continue;
				}
				System.out.println("Enter '0' or '1' to place in (x,y) : ");
				n=scan.next().charAt(0);;
				if(n!='0' && n!='1')
				{
					System.out.println("Enter only either '0' or '1' : ");
					continue;
				}
				if(input[x][y]=='l')
				{
					System.out.println("Cannot change the default '1' ");
				}
				else if(input[x][y]=='O')
				{
					System.out.println("Cannot change the default '0' ");
				}
				else 
				{
					input[x][y]=n;
				}
				for(i=1;i<=size;i++)
				{
					for(j=1;j<=size;j++)
					{
						if(input[i][j]=='.')
						{
							flag=1;
						}
					}
				}
				if(flag==1)
				{
					System.out.print(" ");
					for(i=1;i<=size;i++)
					{
						System.out.print(" "+i);
					}
					System.out.println(" ");
					System.out.print(" ");
					for(i=1;i<=size;i++)
					{
						System.out.print(" _");
					}
					System.out.println(" ");
					for(i=1;i<=size;i++)
					{
						System.out.print(i+"|");
						for(j=1;j<=size;j++)
						{
							System.out.print(input[i][j]+" ");
						}
						System.out.println(" ");
					}	
				}
				else
				{

					for(i=1;i<=size;i++)
					{
						for(j=1;j<=size;j++)
						{
							if(input[i][j]=='1')
								count1++;
							if(input[i][j]=='0')
								count0++;
						}
						if(count0==mid && count1==mid)
						{
							answer0=1;
						}
						else
						{
							answer0=0;
							break;
						}
						count1=0;
						count0=0;
					}

					for(i=1;i<=size;i++)
					{
						for(j=1;j<=size;j++)
						{
							if(input[j][i]=='1')
								count1++;
							if(input[j][i]=='0')
								count0++;
						}
						if(count0==mid && count1==mid)
						{
							answer1=1;
						}
						else
						{
							answer1=0;
						}
						count0=0;
						count1=0;
					}

					for(i=1;i<=size;i++)
					{
						for(j=1;j<=size-2;j++)
						{
							if(input[i][j]==input[i][j+1] && input[i][j+1]==input[i][j+2])
							{
								answer2=0;
								break;
							}
							else
							{
								answer2=1;
							}
						}
						if(answer2==0)
							break;
					}

					for(i=1;i<=size;i++)
					{
						for(j=1;j<=size-2;j++)
						{
							if(input[j][i]==input[j+1][i] && input[j+1][i]==input[j+2][i])
							{
								answer3=0;
								break;
							}
							else
							{
								answer3=1;
							}
						}
						if(answer3==0)
							break;
					}

					for(i=1;i<=size;i++)
					{
						for(j=i+1;j<=size;j++)
						{
							for(k=1;k<=size;k++)
							{
								if(input[i][k]==input[j][k])
								{
									count2++;
								}
							}
							if(count2==size)
							{
								answer4=0;
								break;
							}
							count2=0;
						}
						if(answer4==0)
							break;
					}

					for(i=1;i<=size;i++)
					{
						for(j=i+1;j<=size;j++)
						{
							for(k=1;k<=size;k++)
							{
								if(input[k][i]==input[k][j])
								{
									count3++;
								}
							}
							if(count3==size)
							{
								answer5=0;
								break;
							}
							count3=0;
						}
						if(answer5==0)
							break;
					}

					if(answer0==1 && answer1==1 && answer2==1 && answer3==1 &&  answer4==1 && answer5==1)
					{
						System.out.println("Congratulations , answer is correct");
						System.out.print(" ");
						for(i=1;i<=size;i++)
						{
							System.out.print(" "+i);
						}
						System.out.println(" ");
						System.out.print(" ");
						for(i=1;i<=size;i++)
						{
							System.out.print(" _");
						}
						System.out.println(" ");
						for(i=1;i<=size;i++)
						{
							System.out.print(i+"|");
							for(j=1;j<=size;j++)
							{
								System.out.print(input[i][j]+" ");
							}
							System.out.println(" ");
						}
						break;
					}
					else
					{
						System.out.println("Sorry , answer is incorrect");
						System.out.print(" ");
						for(i=1;i<=size;i++)
						{
							System.out.print(" "+i);
						}
						System.out.println(" ");
						System.out.print(" ");
						for(i=1;i<=size;i++)
						{
							System.out.print(" _");
						}
						System.out.println(" ");
						for(i=1;i<=size;i++)
						{
							System.out.print(i+"|");
							for(j=1;j<=size;j++)
							{
								System.out.print(input[i][j]+" ");
							}
							System.out.println(" ");
						}
						break;
					}
				}
				flag=0;	
			}
		}
		else
		{
			System.out.println("Incorrect mode");
		}

	}
}